# SIMKUA Pintar - Sistem Informasi Manajemen Kantor Urusan Agama

Aplikasi web terpadu untuk digitalisasi tata kelola administrasi Kantor Urusan Agama (KUA) Kementerian Agama Republik Indonesia, yang mengintegrasikan registrasi nikah/rujuk, pencatatan surat masuk dan keluar, manajemen arsip dokumen digital terpusat, notifikasi tugas mendesak, generator laporan resmi bulanan PDF berstandar Kemenag (Model N & LNR), serta pengawasan rekam jejak staf berbasis hak akses bertingkat.

## User Review & Critical Decisions

> [!IMPORTANT]
> Ringkasan keputusan hasil klarifikasi kebutuhan dan rekomendasi arsitektur:

- **Nama & Identitas Resmi**: Disetujui menggunakan nama **SIMKUA Pintar - Kantor Urusan Agama** dengan atribut resmi Kemenag (Kementerian Agama RI).
- **Arsitektur Sinkronisasi & Arsip**: Firebase Firestore untuk sinkronisasi multi-user real-time yang aman, dilengkapi penyimpanan lokal (IndexedDB / LocalStorage terenkripsi) agar petugas KUA di daerah dengan koneksi terbatas tetap dapat menginput data secara offline (offline-first sync).
- **Standar Laporan & Cetak PDF**: Format cetak mengacu pada regulasi PMA Kemenag RI, mencakup formulir Model N (Pemeriksaan Nikah N2, Persetujuan Calon Mempelai N3, Surat Keterangan N4), Buku Register Nikah resmi, Laporan Bulanan Nikah & Rujuk (LNR), serta Lembar Disposisi Surat Dinas.
- **Tingkatan Hak Akses Staf (RBAC)**:
  1. *Kepala KUA*: Otorisasi disposisi surat, persetujuan berkas nikah, download laporan resmi, monitoring audit log seluruh staf.
  2. *Penghulu*: Jadwal pemeriksaan berkas, penugasan akad nikah, pencatatan buku nikah & akta nikah.
  3. *Staf Tata Usaha / Operator*: Pendaftaran calon pengantin, registrasi surat masuk/keluar, scan & unggah arsip berkas.
  4. *Verifikator Dokumen*: Pemeriksaan validitas dokumen kependudukan & keaslian syarat administratif.

---

## 1. Overview & Core Concept

### What It Does
SIMKUA Pintar mentransformasikan alur kerja manual KUA menjadi sistem digital satu pintu yang tertib, cepat, dan akuntabel:
- **Register Pendaftaran Nikah**: Pencatatan lengkap data calon pengantin pria & wanita, wali nikah, saksi, status berkas (Pendaftaran, Pemeriksaan/NB, Pengumuman Kehendak Nikah, Siap Akad, Selesai Akad), serta jadwal dan lokasi (Bedol / Luar Kantor vs KUA).
- **Register Surat Masuk & Keluar**: Agenda surat dinas dengan nomor agenda otomatis, pengelompokan klasifikasi surat, ringkasan perihal, pelacakan lembar disposisi digital oleh Kepala KUA, dan status tindak lanjut.
- **Pusat Arsip Dokumen Digital**: Repository aman untuk berkas NIK/KTP, Kartu Keluarga, Akta Kelahiran, Ijazah, Surat Keterangan Imunisasi, N-1 s.d N-5, serta dokumen dinas dengan fitur pratinjau instan dan penandaan kategori.
- **Sistem Notifikasi Tugas Mendesak**: Deteksi otomatis berkas belum lengkap (H-10 akad), jadwal akad H-3, serta disposisi surat masuk yang belum ditindaklanjuti lebih dari 48 jam.
- **Dasbor Analitik Performa Harian & Bulanan**: Grafik visualisasi tren pernikahan bulanan, rasio nikah di kantor vs bedol, distribusi hari favorit akad, beban kerja penghulu, dan volume surat.
- **Laporan Bulanan PDF Instan**: Cetak berkas LNR, Buku Register Nikah, Agenda Surat, dan Lembar Disposisi dengan format tata letak kop dinas resmi, tabel presisi, dan barcode validasi.
- **Audit Log Staf Transparan**: Pencatatan riwayat setiap aksi staf (waktu, nama staf, peran, aksi, nomor berkas) untuk mencegah manipulasi data.

### Target Audience & Persona
- **Kepala KUA**: Membutuhkan pengawasan terpusat, persetujuan berkas cepat, dan laporan eksekutif tanpa harus menunggu rekap manual mingguan.
- **Penghulu & Penghulu Pembantu**: Membutuhkan kalender jadwal akad terintegrasi dan pencatatan nomor akta nikah yang rapi.
- **Operator KUA & Staf TU**: Membutuhkan input form cepat, auto-fill tanggal hijriah/masehi, dan pencarian berkas arsip dalam hitungan detik.

---

## 2. User Experience & Visual Design

### Key User Flows
1. **Pendaftaran Calon Pengantin (Catin)**:
   - Operator membuka modul "Daftar Nikah Baru" $\rightarrow$ Input NIK, data calon suami, calon istri, wali nikah $\rightarrow$ Pilih jadwal & lokasi akad $\rightarrow$ Upload berkas persyaratan $\rightarrow$ Sistem menghasilkan Nomor Registrasi dan estimasi hari akad dengan notifikasi H-3 otomatis.
2. **Pengelolaan Surat & Disposisi**:
   - Staf TU menginput surat masuk $\rightarrow$ Kepala KUA menerima notifikasi di dasbor $\rightarrow$ Mengisi catatan disposisi & menunjuk staf pelaksana $\rightarrow$ Staf pelaksana mengubah status menjadi "Selesai Tindak Lanjut".
3. **Penyimpanan & Pencarian Arsip**:
   - Filter cepat berdasarkan kategori (Berkas Nikah, Surat Keputusan, Arsip Wakaf, Dokumen Rujuk) $\rightarrow$ Pratinjau dokumen langsung $\rightarrow$ Pengunduhan aman.
4. **Penerbitan Laporan PDF Bulanan**:
   - Pilih bulan dan tahun $\rightarrow$ Pratinjau ringkasan statistik LNR $\rightarrow$ Klik "Unduh PDF Laporan Bulanan" $\rightarrow$ File tergenerasi instan dengan kop resmi Kemenag dan tabel rapi siap cetak/arsip.

### Visual Identity & Theme
Mengacu pada standar desain Enterprise Government SaaS (`references/3_saas_dashboard.md`):
- **Aesthetic Direction**: *Institutional, Trustworthy, Modern Islamic-Administrative*. Bersih, berwibawa, tanpa ornamen berlebihan atau efek neon AI yang lazim.
- **Color Palette**:
  - *Dominant Canvas (60%)*: Bersih bernuansa emerald slate lembut (`bg-slate-50` / `bg-white`) yang mencerminkan institusi Kemenag.
  - *Structural Surfaces (30%)*: Emerald deep pine `#0F5132` / `#064E3B` untuk identitas navigasi Kemenag, didukung border hairline netral `border-slate-200`.
  - *Accents (10%)*: Gold amber `#D97706` untuk highlight peringatan tugas mendesak, jade green `#059669` untuk status berhasil/selesai, serta ruby `#DC2626` untuk batas waktu terlampaui.
- **Typography & Hierarchy**:
  - *Brand & Display*: Plus Jakarta Sans untuk keterbacaan modern dan wibawa institusional.
  - *Body Prose*: Public Sans / Inter yang rapat dan mudah dipindai di tabel data.
  - *Data & Timestamps*: Monospace tabular figures (`tabular-nums font-mono`) pada Nomor Register, NIK, tanggal, dan jam akad.
- **Layout Integrity**:
  - Sidebar tetap (width 260px) dengan logo Kemenag & SIMKUA Pintar.
  - Top header 3-zona: Breadcrumb lokasi aktif, status sinkronisasi Firebase & mode offline, profil user aktif dengan role badge.
  - Viewport 1440px dengan data grid berkepadatan tinggi (row height 40px-44px), zero-pill text metadata berpemisah `·`.

---

## 3. Key Product Decisions & Trade-Offs

1. **Format PDF Generasi Klien (Client-side JSPDF / AutoTable)**:
   - *Pilihan*: Menggunakan rendering PDF langsung di sisi klien dengan template format Kemenag presisi tinggi.
   - *Alasan*: Kompatibel penuh dengan hosting statis / GitHub Pages tanpa memerlukan backend Node renderer eksternal yang berat, serta menghasilkan file instan tanpa latensi server.
2. **Offline-First Firebase Architecture**:
   - *Pilihan*: Data tersimpan di memory/local storage dengan listener real-time Firestore. Saat terputus dari jaringan, seluruh operasi CRUD tetap berfungsi dan akan melakukan sinkronisasi otomatis saat terhubung kembali.
   - *Alasan*: KUA kecamatan sering kali mengalami fluktuasi jaringan internet; sistem tidak boleh macet ketika sedang melayani masyarakat di loket.
3. **Role-Based Action Segregation (RBAC)**:
   - *Pilihan*: Otorisasi aksi terdistribusi secara ketat. Operator tidak bisa mengubah status disposisi kepala kantor; staf biasa tidak dapat menghapus log audit.

---

## 4. Technical Architecture & Data Strategy

### System Component Diagram

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                       SIMKUA Pintar Web Architecture                        │
└─────────────────────────────────────────────────────────────────────────────┘
                                       │
            ┌──────────────────────────┴──────────────────────────┐
            ▼                                                     ▼
┌───────────────────────┐                             ┌───────────────────────┐
│  Navigation & Top Bar │                             │  RBAC Auth & Session  │
│ - Breadcrumbs Context │                             │ - Kepala KUA / Staf   │
│ - Sync State Pill     │                             │ - Switch Role Preview │
│ - Urgent Notif Center │                             │ - Secure Login Dialog │
└───────────────────────┘                             └───────────────────────┘
            │                                                     │
            ▼                                                     ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│                              Core Workspaces                                │
│ ┌──────────────────┐ ┌──────────────────┐ ┌──────────────────┐ ┌──────────┐ │
│ │ Register Nikah   │ │ Register Surat   │ │ Digital Archive  │ │ Laporan  │ │
│ │ - Catin Form     │ │ - Masuk & Keluar │ │ - Metadata Tags  │ │   Bulanan│ │
│ │ - Jadwal Akad    │ │ - Disposisi Flow │ │ - Preview Modal  │ │ - LNR    │ │
│ │ - Model N Cetak  │ │ - No. Agenda Auto│ │ - Upload Berkas  │ │ - PDF Gen│ │
│ └──────────────────┘ └──────────────────┘ └──────────────────┘ └──────────┘ │
│ ┌───────────────────────────────────────┐ ┌───────────────────────────────┐ │
│ │ Analytics & Performance Dashboard     │ │ Transparent Audit Activity Log│ │
│ │ - Tren Bulanan / Rasio Bedol          │ │ - Timestamp, Aktor, Modifikasi│ │
│ └───────────────────────────────────────┘ └───────────────────────────────┘ │
└─────────────────────────────────────────────────────────────────────────────┘
                                       │
            ┌──────────────────────────┴──────────────────────────┐
            ▼                                                     ▼
┌──────────────────────────────────────────┐ ┌────────────────────────────────┐
│ Data Engine (Firebase + Offline Storage) │ │ Export Engine                  │
│ - Firestore Collections & Listeners      │ │ - jsPDF / AutoTable Kemenag    │
│ - End-to-End Field Encryption / Masking  │ │ - Model N1-N4 & Agenda Surat   │
│ - Auto Backup & JSON Data Seed           │ │ - Disposisi Slip PDF           │
└──────────────────────────────────────────┘ └────────────────────────────────┘
```

### Data Model & Entities
1. **NikahRegistration**:
   - `id`: string (NIK/UUID)
   - `noPendaftaran`: string (e.g. `REG-2026/03/NK-042`)
   - `calonSuami`: `{ nama, nik, tglLahir, status, namaAyah, alamat, noHp }`
   - `calonIstri`: `{ nama, nik, tglLahir, status, namaAyah, alamat, noHp }`
   - `waliNikah`: `{ nama, hubungan, nik, alamat }`
   - `jadwalAkad`: `{ tanggal, jam, lokasi: 'KUA' | 'Luar KUA (Bedol)', alamatAkad }`
   - `penghuluId`: string (ID staf penghulu bertugas)
   - `status`: `'Pendaftaran'` | `'Pemeriksaan'` | `'Pengumuman'` | `'Siap Akad'` | `'Selesai'` | `'Ditolak'`
   - `berkasDokumen`: array of `{ nama, jenis, url, uploadedAt }`
   - `noAktaNikah` & `noBukuNikah`: string (opsional jika sudah selesai)
   - `createdAt`, `updatedAt`: timestamp
2. **SuratRecord**:
   - `id`: string
   - `jenis`: `'Surat Masuk'` | `'Surat Keluar'`
   - `noAgenda`: string
   - `noSurat`: string
   - `tglSurat`, `tglDiterima`: string
   - `pengirim`, `tujuan`: string
   - `perihal`: string
   - `klasifikasi`: string (e.g. Kedinasan, Permohonan, Undangan, Laporan)
   - `disposisi`: `{ catatan, instruksi, ditujukanKe, batasWaktu, status }`
   - `lampiranFile`: string
3. **ArsipDigital**:
   - `id`, `judul`, `kategori`, `noReferensi`, `tglDokumen`, `keterangan`, `fileSize`, `uploadedBy`
4. **AuditLog**:
   - `id`, `timestamp`, `userId`, `userName`, `userRole`, `action`, `resourceType`, `resourceId`, `detail`
5. **StaffUser**:
   - `id`, `name`, `nip`, `email`, `role`, `jabatan`, `avatar`

---

Rencana implementasi di atas siap dieksekusi setelah persetujuan Anda.
